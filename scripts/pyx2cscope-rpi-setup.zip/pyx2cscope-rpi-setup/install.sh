#!/bin/bash
#===============================================================================
# pyX2Cscope Raspberry Pi Installer
#
# This script installs pyX2Cscope with web interface on Raspberry Pi and
# configures it to start automatically in kiosk mode.
#
# Usage:
#   chmod +x install.sh
#   ./install.sh
#
# Requirements:
#   - Raspberry Pi with Raspberry Pi OS (Debian 12 Bookworm)
#   - Internet connection
#   - Microchip debugger connected (PKOB4, ICD4, etc.)
#===============================================================================

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
INSTALL_DIR="$HOME/.local/share/pyx2cscope"
VENV_DIR="$INSTALL_DIR/venv"
SERVICE_NAME="pyx2cscope"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo -e "${BLUE}"
echo "=============================================="
echo "   pyX2Cscope Raspberry Pi Installer"
echo "   Microchip Technology Inc."
echo "=============================================="
echo -e "${NC}"

#-------------------------------------------------------------------------------
# Check if running on Raspberry Pi
#-------------------------------------------------------------------------------
check_raspberry_pi() {
    echo -e "${YELLOW}[1/8] Checking system...${NC}"

    if [ ! -f /etc/os-release ]; then
        echo -e "${RED}Error: Cannot detect OS. This script is for Raspberry Pi OS.${NC}"
        exit 1
    fi

    . /etc/os-release
    echo "  OS: $PRETTY_NAME"
    echo "  User: $USER"
    echo "  Home: $HOME"

    if ! grep -q "Debian\|Raspbian" /etc/os-release; then
        echo -e "${YELLOW}  Warning: This script is designed for Raspberry Pi OS (Debian-based)${NC}"
        read -p "  Continue anyway? (y/n) " -n 1 -r
        echo
        if [[ ! $REPLY =~ ^[Yy]$ ]]; then
            exit 1
        fi
    fi

    echo -e "${GREEN}  System check passed${NC}"
}

#-------------------------------------------------------------------------------
# Install system dependencies
#-------------------------------------------------------------------------------
install_dependencies() {
    echo -e "${YELLOW}[2/8] Installing system dependencies...${NC}"

    sudo apt-get update
    sudo apt-get install -y \
        python3 \
        python3-venv \
        python3-pip \
        chromium-browser \
        libgl1-mesa-glx \
        libxcb-xinerama0 \
        libxkbcommon-x11-0 \
        libxcb-icccm4 \
        libxcb-image0 \
        libxcb-keysyms1 \
        libxcb-randr0 \
        libxcb-render-util0 \
        libxcb-shape0

    echo -e "${GREEN}  Dependencies installed${NC}"
}

#-------------------------------------------------------------------------------
# Add user to dialout group for serial port access
#-------------------------------------------------------------------------------
setup_serial_permissions() {
    echo -e "${YELLOW}[3/8] Setting up serial port permissions...${NC}"

    if groups $USER | grep -q dialout; then
        echo "  User already in dialout group"
    else
        sudo usermod -a -G dialout $USER
        echo -e "${GREEN}  Added $USER to dialout group${NC}"
        echo -e "${YELLOW}  NOTE: You may need to log out and back in for this to take effect${NC}"
    fi
}

#-------------------------------------------------------------------------------
# Create virtual environment and install pyX2Cscope
#-------------------------------------------------------------------------------
install_pyx2cscope() {
    echo -e "${YELLOW}[4/8] Installing pyX2Cscope...${NC}"

    # Create install directory
    mkdir -p "$INSTALL_DIR"

    # Create virtual environment
    if [ -d "$VENV_DIR" ]; then
        echo "  Virtual environment exists, upgrading..."
    else
        echo "  Creating virtual environment..."
        python3 -m venv "$VENV_DIR"
    fi

    # Upgrade pip
    "$VENV_DIR/bin/pip" install --upgrade pip

    # Install pyX2Cscope
    echo "  Installing pyX2Cscope (this may take a few minutes)..."
    "$VENV_DIR/bin/pip" install pyx2cscope

    # Verify installation
    VERSION=$("$VENV_DIR/bin/pip" show pyx2cscope | grep Version | cut -d' ' -f2)
    echo -e "${GREEN}  pyX2Cscope $VERSION installed${NC}"
}

#-------------------------------------------------------------------------------
# Detect serial port
#-------------------------------------------------------------------------------
detect_serial_port() {
    echo -e "${YELLOW}[5/8] Detecting serial port...${NC}"

    # Look for common Microchip debugger ports
    if [ -e /dev/ttyACM0 ]; then
        SERIAL_PORT="/dev/ttyACM0"
    elif [ -e /dev/ttyUSB0 ]; then
        SERIAL_PORT="/dev/ttyUSB0"
    else
        echo -e "${YELLOW}  No debugger detected. Please connect your Microchip debugger.${NC}"
        echo "  Available serial ports:"
        ls /dev/tty* 2>/dev/null | grep -E 'USB|ACM' || echo "    None found"

        read -p "  Enter serial port path (e.g., /dev/ttyACM0): " SERIAL_PORT

        if [ ! -e "$SERIAL_PORT" ]; then
            echo -e "${YELLOW}  Warning: Port $SERIAL_PORT does not exist yet.${NC}"
            echo "  The service will start when the debugger is connected."
        fi
    fi

    echo -e "${GREEN}  Using serial port: $SERIAL_PORT${NC}"
}

#-------------------------------------------------------------------------------
# Get ELF file path
#-------------------------------------------------------------------------------
get_elf_path() {
    echo -e "${YELLOW}[6/8] Configuring ELF file...${NC}"

    # Look for .elf files on Desktop
    ELF_FILES=$(find "$HOME/Desktop" -name "*.elf" 2>/dev/null | head -5)

    if [ -n "$ELF_FILES" ]; then
        echo "  Found ELF files on Desktop:"
        echo "$ELF_FILES" | while read f; do echo "    - $(basename "$f")"; done

        # Use the first one found
        ELF_PATH=$(echo "$ELF_FILES" | head -1)
        echo ""
        read -p "  Use $ELF_PATH? (y/n) " -n 1 -r
        echo

        if [[ ! $REPLY =~ ^[Yy]$ ]]; then
            read -p "  Enter full path to ELF file: " ELF_PATH
        fi
    else
        echo "  No ELF files found on Desktop."
        read -p "  Enter full path to ELF file (or press Enter to skip): " ELF_PATH
    fi

    if [ -n "$ELF_PATH" ] && [ ! -f "$ELF_PATH" ]; then
        echo -e "${YELLOW}  Warning: ELF file not found. You can add it later.${NC}"
        ELF_PATH=""
    fi

    if [ -n "$ELF_PATH" ]; then
        echo -e "${GREEN}  Using ELF file: $ELF_PATH${NC}"
    else
        echo -e "${YELLOW}  No ELF file configured. You can select one in the web interface.${NC}"
    fi
}

#-------------------------------------------------------------------------------
# Create systemd service
#-------------------------------------------------------------------------------
create_service() {
    echo -e "${YELLOW}[7/8] Creating systemd service...${NC}"

    # Build ExecStart command
    EXEC_CMD="$VENV_DIR/bin/python -m pyx2cscope -w --host 0.0.0.0"

    if [ -n "$ELF_PATH" ] && [ -n "$SERIAL_PORT" ]; then
        EXEC_CMD="$EXEC_CMD -e $ELF_PATH -p $SERIAL_PORT"
    fi

    # Create service file
    SERVICE_FILE="/etc/systemd/system/$SERVICE_NAME.service"

    sudo tee "$SERVICE_FILE" > /dev/null << EOF
[Unit]
Description=pyX2Cscope Web Interface
After=network.target

[Service]
Type=simple
User=$USER
WorkingDirectory=$HOME
Environment=PATH=$VENV_DIR/bin:/usr/bin
Environment=HOME=$HOME
ExecStart=$EXEC_CMD
Restart=on-failure
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF

    # Reload systemd and enable service
    sudo systemctl daemon-reload
    sudo systemctl enable $SERVICE_NAME
    sudo systemctl start $SERVICE_NAME

    echo -e "${GREEN}  Service created and started${NC}"

    # Check status
    sleep 2
    if systemctl is-active --quiet $SERVICE_NAME; then
        echo -e "${GREEN}  Service is running${NC}"
    else
        echo -e "${YELLOW}  Service may need the debugger to be connected${NC}"
    fi
}

#-------------------------------------------------------------------------------
# Setup Chromium kiosk mode
#-------------------------------------------------------------------------------
setup_kiosk() {
    echo -e "${YELLOW}[8/8] Setting up kiosk mode...${NC}"

    read -p "  Enable kiosk mode (fullscreen browser on boot)? (y/n) " -n 1 -r
    echo

    if [[ $REPLY =~ ^[Yy]$ ]]; then
        # Create autostart directory
        mkdir -p "$HOME/.config/autostart"

        # Create desktop file
        cat > "$HOME/.config/autostart/chromium-kiosk.desktop" << EOF
[Desktop Entry]
Type=Application
Name=pyX2Cscope Kiosk
Comment=Open pyX2Cscope in fullscreen browser
Exec=bash -c "sleep 5 && chromium-browser --start-fullscreen --noerrdialogs --disable-infobars --disable-session-crashed-bubble --password-store=basic --check-for-update-interval=31536000 http://localhost:5000"
Terminal=false
X-GNOME-Autostart-enabled=true
EOF

        echo -e "${GREEN}  Kiosk mode enabled${NC}"
        echo "  Chromium will open in fullscreen after reboot"
        echo "  Press Alt+F4 to exit fullscreen"
    else
        echo "  Kiosk mode skipped"
    fi
}

#-------------------------------------------------------------------------------
# Print summary
#-------------------------------------------------------------------------------
print_summary() {
    echo ""
    echo -e "${BLUE}=============================================="
    echo "   Installation Complete!"
    echo "==============================================${NC}"
    echo ""
    echo "  pyX2Cscope Web Interface: http://localhost:5000"
    echo "  From other devices:       http://$(hostname).local:5000"
    echo ""
    echo "  Service commands:"
    echo "    sudo systemctl status pyx2cscope   # Check status"
    echo "    sudo systemctl restart pyx2cscope  # Restart"
    echo "    sudo systemctl stop pyx2cscope     # Stop"
    echo "    journalctl -u pyx2cscope -f        # View logs"
    echo ""

    if [ -f "$HOME/.config/autostart/chromium-kiosk.desktop" ]; then
        echo "  Kiosk mode: ENABLED (reboot to activate)"
        echo "  To disable: rm ~/.config/autostart/chromium-kiosk.desktop"
        echo ""
    fi

    echo -e "${YELLOW}  NOTE: If this is a fresh install, please reboot your Pi:${NC}"
    echo "    sudo reboot"
    echo ""
}

#-------------------------------------------------------------------------------
# Main
#-------------------------------------------------------------------------------
main() {
    check_raspberry_pi
    install_dependencies
    setup_serial_permissions
    install_pyx2cscope
    detect_serial_port
    get_elf_path
    create_service
    setup_kiosk
    print_summary
}

main "$@"
