#!/bin/bash
#===============================================================================
# pyX2Cscope Configuration Tool
#
# Use this script to change settings after installation:
#   - Change ELF file
#   - Change serial port
#   - Enable/disable kiosk mode
#===============================================================================

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

INSTALL_DIR="$HOME/.local/share/pyx2cscope"
VENV_DIR="$INSTALL_DIR/venv"
SERVICE_NAME="pyx2cscope"
SERVICE_FILE="/etc/systemd/system/$SERVICE_NAME.service"

echo -e "${BLUE}pyX2Cscope Configuration Tool${NC}"
echo ""

# Check if installed
if [ ! -d "$VENV_DIR" ]; then
    echo -e "${RED}Error: pyX2Cscope is not installed. Run install.sh first.${NC}"
    exit 1
fi

# Show current configuration
echo "Current configuration:"
if [ -f "$SERVICE_FILE" ]; then
    CURRENT_CMD=$(grep "ExecStart=" "$SERVICE_FILE" | cut -d'=' -f2-)
    echo "  Command: $CURRENT_CMD"
fi
echo ""

# Menu
PS3="Select option: "
options=("Change ELF file" "Change serial port" "Toggle kiosk mode" "View service status" "View logs" "Restart service" "Exit")

select opt in "${options[@]}"; do
    case $opt in
        "Change ELF file")
            echo ""
            echo "Current ELF files on Desktop:"
            find "$HOME/Desktop" -name "*.elf" 2>/dev/null || echo "  None found"
            echo ""
            read -p "Enter full path to new ELF file: " NEW_ELF

            if [ -f "$NEW_ELF" ]; then
                # Get current serial port from service file
                CURRENT_PORT=$(grep "ExecStart=" "$SERVICE_FILE" | grep -oP '\-p\s+\K[^\s]+' || echo "/dev/ttyACM0")

                # Update service
                EXEC_CMD="$VENV_DIR/bin/python -m pyx2cscope -w --host 0.0.0.0 -e $NEW_ELF -p $CURRENT_PORT"

                sudo sed -i "s|ExecStart=.*|ExecStart=$EXEC_CMD|" "$SERVICE_FILE"
                sudo systemctl daemon-reload
                sudo systemctl restart $SERVICE_NAME

                echo -e "${GREEN}ELF file updated and service restarted${NC}"
            else
                echo -e "${RED}File not found: $NEW_ELF${NC}"
            fi
            ;;

        "Change serial port")
            echo ""
            echo "Available serial ports:"
            ls /dev/tty* 2>/dev/null | grep -E 'USB|ACM' || echo "  None found"
            echo ""
            read -p "Enter serial port (e.g., /dev/ttyACM0): " NEW_PORT

            # Get current ELF from service file
            CURRENT_ELF=$(grep "ExecStart=" "$SERVICE_FILE" | grep -oP '\-e\s+\K[^\s]+' || echo "")

            if [ -n "$CURRENT_ELF" ]; then
                EXEC_CMD="$VENV_DIR/bin/python -m pyx2cscope -w --host 0.0.0.0 -e $CURRENT_ELF -p $NEW_PORT"
            else
                EXEC_CMD="$VENV_DIR/bin/python -m pyx2cscope -w --host 0.0.0.0"
            fi

            sudo sed -i "s|ExecStart=.*|ExecStart=$EXEC_CMD|" "$SERVICE_FILE"
            sudo systemctl daemon-reload
            sudo systemctl restart $SERVICE_NAME

            echo -e "${GREEN}Serial port updated and service restarted${NC}"
            ;;

        "Toggle kiosk mode")
            KIOSK_FILE="$HOME/.config/autostart/chromium-kiosk.desktop"

            if [ -f "$KIOSK_FILE" ]; then
                rm -f "$KIOSK_FILE"
                echo -e "${GREEN}Kiosk mode DISABLED${NC}"
            else
                mkdir -p "$HOME/.config/autostart"
                cat > "$KIOSK_FILE" << 'EOF'
[Desktop Entry]
Type=Application
Name=pyX2Cscope Kiosk
Comment=Open pyX2Cscope in fullscreen browser
Exec=bash -c "sleep 5 && chromium-browser --start-fullscreen --noerrdialogs --disable-infobars --disable-session-crashed-bubble --password-store=basic --check-for-update-interval=31536000 http://localhost:5000"
Terminal=false
X-GNOME-Autostart-enabled=true
EOF
                echo -e "${GREEN}Kiosk mode ENABLED (will activate on next reboot)${NC}"
            fi
            ;;

        "View service status")
            echo ""
            systemctl status $SERVICE_NAME --no-pager || true
            ;;

        "View logs")
            echo ""
            echo "Press Ctrl+C to exit log view"
            journalctl -u $SERVICE_NAME -f
            ;;

        "Restart service")
            sudo systemctl restart $SERVICE_NAME
            echo -e "${GREEN}Service restarted${NC}"
            ;;

        "Exit")
            break
            ;;

        *)
            echo "Invalid option"
            ;;
    esac
    echo ""
done
