#!/bin/bash
#===============================================================================
# pyX2Cscope Uninstaller
#
# Removes pyX2Cscope and all related configurations from Raspberry Pi.
#===============================================================================

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

INSTALL_DIR="$HOME/.local/share/pyx2cscope"
SERVICE_NAME="pyx2cscope"

echo -e "${YELLOW}pyX2Cscope Uninstaller${NC}"
echo ""

read -p "This will remove pyX2Cscope and all configurations. Continue? (y/n) " -n 1 -r
echo

if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "Cancelled."
    exit 0
fi

echo "Stopping service..."
sudo systemctl stop $SERVICE_NAME 2>/dev/null || true
sudo systemctl disable $SERVICE_NAME 2>/dev/null || true

echo "Removing service file..."
sudo rm -f /etc/systemd/system/$SERVICE_NAME.service
sudo systemctl daemon-reload

echo "Removing kiosk autostart..."
rm -f "$HOME/.config/autostart/chromium-kiosk.desktop"

echo "Removing pyX2Cscope installation..."
rm -rf "$INSTALL_DIR"

echo ""
echo -e "${GREEN}pyX2Cscope has been removed.${NC}"
echo "Note: User remains in dialout group (harmless to keep)."
