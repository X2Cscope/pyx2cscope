![Microchip Logo](assets/logo.png "Microchip Technology")

# pyX2Cscope Raspberry Pi Installer

**One-click installer for pyX2Cscope web interface on Raspberry Pi with optional kiosk mode**

![Version](https://img.shields.io/badge/version-1.0.0-green)
![Platform](https://img.shields.io/badge/platform-Raspberry%20Pi-C51A4A)
![pyX2Cscope](https://img.shields.io/badge/pyX2Cscope-0.7.0-blue)
![License](https://img.shields.io/badge/license-proprietary-red)
![Updated](https://img.shields.io/badge/updated-2026--05--15-informational)

---

## Table of Contents

- [About](#about)
- [Features](#features)
- [Prerequisites](#prerequisites)
- [Quick Start](#quick-start)
- [Installation](#installation)
- [Configuration](#configuration)
- [Usage](#usage)
- [Troubleshooting](#troubleshooting)
- [Uninstallation](#uninstallation)
- [License](#license)
- [Contact](#contact)

---

## About

This package provides automated installation scripts to set up **pyX2Cscope** on a Raspberry Pi as a dedicated motor control monitoring station. The installer configures:

- pyX2Cscope web interface accessible from any browser
- Automatic startup as a system service
- Optional kiosk mode for dedicated display setups
- Serial port permissions for Microchip debuggers

### What is pyX2Cscope?

pyX2Cscope is Microchip's Python implementation of X2Cscope, providing real-time variable monitoring and control for embedded motor control applications. It connects to Microchip debuggers (PKOB4, ICD4, PICkit, etc.) to read and write variables in running firmware.

---

## Features

- **One-Click Install**: Single script handles all dependencies and configuration
- **Web Interface**: Access from any device on your network at `http://raspberrypi.local:5000`
- **Auto-Start Service**: pyX2Cscope starts automatically on boot
- **Kiosk Mode**: Optional fullscreen browser mode for dedicated displays
- **ELF Auto-Load**: Configure automatic loading of your firmware ELF file
- **Easy Configuration**: Change settings anytime with the configure tool

---

## Prerequisites

| Requirement | Details |
|-------------|---------|
| Hardware | Raspberry Pi 4 or 5 (recommended) |
| OS | Raspberry Pi OS (Debian 12 Bookworm) |
| Network | Internet connection for installation |
| Debugger | Microchip PKOB4, ICD4, PICkit 4/5, or compatible |
| Display | Optional - for kiosk mode |

### Supported Debuggers

- MPLAB PKOB 4 (on-board debugger)
- MPLAB ICD 4 / ICD 5
- MPLAB PICkit 4 / PICkit 5
- MPLAB Snap
- Any debugger supporting X2Cscope protocol

---

## Quick Start

### Option 1: Copy folder to Raspberry Pi

1. Copy this entire folder to your Raspberry Pi
2. Open terminal in the folder
3. Run:

```bash
chmod +x install.sh
./install.sh
```

### Option 2: Download directly on Pi

```bash
# On your Raspberry Pi:
git clone <repository-url> pyx2cscope-setup
cd pyx2cscope-setup
chmod +x install.sh
./install.sh
```

---

## Installation

### Step-by-Step Installation

1. **Transfer files to Raspberry Pi**

   Copy this folder to your Pi using USB, SCP, or network share:
   ```bash
   # From your PC (replace IP with your Pi's address):
   scp -r pyx2cscope-rpi-setup pi@raspberrypi.local:~/
   ```

2. **Connect to Raspberry Pi**
   ```bash
   ssh pi@raspberrypi.local
   ```

3. **Run the installer**
   ```bash
   cd ~/pyx2cscope-rpi-setup
   chmod +x install.sh
   ./install.sh
   ```

4. **Follow the prompts**
   - The installer will ask about:
     - Serial port (auto-detected if debugger connected)
     - ELF file location (optional)
     - Kiosk mode (yes/no)

5. **Reboot** (recommended for first install)
   ```bash
   sudo reboot
   ```

### What the Installer Does

1. Installs system dependencies (Python, Chromium, etc.)
2. Adds user to `dialout` group for serial port access
3. Creates Python virtual environment at `~/.local/share/pyx2cscope/`
4. Installs pyX2Cscope via pip
5. Creates systemd service for auto-start
6. Optionally configures Chromium kiosk mode

---

## Configuration

### After Installation

Run the configuration tool to change settings:

```bash
./configure.sh
```

Options available:
- Change ELF file
- Change serial port
- Toggle kiosk mode on/off
- View service status
- View logs
- Restart service

### Manual Configuration

#### Change ELF File

Edit the service file:
```bash
sudo nano /etc/systemd/system/pyx2cscope.service
```

Modify the `ExecStart` line to include your ELF path:
```
ExecStart=/home/pi/.local/share/pyx2cscope/venv/bin/python -m pyx2cscope -w --host 0.0.0.0 -e /path/to/your/firmware.elf -p /dev/ttyACM0
```

Then reload:
```bash
sudo systemctl daemon-reload
sudo systemctl restart pyx2cscope
```

#### Disable Kiosk Mode

```bash
rm ~/.config/autostart/chromium-kiosk.desktop
```

#### Enable Kiosk Mode

```bash
./configure.sh
# Select "Toggle kiosk mode"
```

---

## Usage

### Accessing the Web Interface

| Access Method | URL |
|---------------|-----|
| From the Pi itself | `http://localhost:5000` |
| From network (hostname) | `http://raspberrypi.local:5000` |
| From network (IP) | `http://<pi-ip-address>:5000` |

### Service Commands

```bash
# Check if service is running
sudo systemctl status pyx2cscope

# Start/stop/restart service
sudo systemctl start pyx2cscope
sudo systemctl stop pyx2cscope
sudo systemctl restart pyx2cscope

# View live logs
journalctl -u pyx2cscope -f

# View recent logs
journalctl -u pyx2cscope -n 50
```

### Kiosk Mode Controls

When kiosk mode is enabled:
- **Alt+F4**: Exit fullscreen browser
- **Ctrl+Alt+T**: Open terminal (on some setups)
- **SSH**: Always available for remote access

---

## Troubleshooting

### Service won't start

**Check logs:**
```bash
journalctl -u pyx2cscope -n 30
```

**Common causes:**
- Debugger not connected (`ValueError: A communication port must be supplied!`)
- Wrong serial port path
- ELF file not found

### "Permission denied" on serial port

Ensure user is in dialout group:
```bash
groups $USER  # Should include 'dialout'
```

If not, add and reboot:
```bash
sudo usermod -a -G dialout $USER
sudo reboot
```

### Can't access web interface from network

1. Check service is running:
   ```bash
   sudo systemctl status pyx2cscope
   ```

2. Check firewall (if enabled):
   ```bash
   sudo ufw allow 5000/tcp
   ```

3. Verify Pi's IP address:
   ```bash
   hostname -I
   ```

### Kiosk mode shows keyring prompt

This should be fixed by the `--password-store=basic` flag. If it still appears:

```bash
# Remove keyring password (set to empty)
rm ~/.local/share/keyrings/*
```

### Chromium crashes or shows errors

Clear Chromium cache:
```bash
rm -rf ~/.config/chromium/
```

---

## Uninstallation

To completely remove pyX2Cscope:

```bash
./uninstall.sh
```

This removes:
- pyX2Cscope installation
- Systemd service
- Kiosk autostart configuration

It does NOT remove:
- System dependencies (Python, Chromium)
- User from dialout group

---

## File Structure

```
pyx2cscope-rpi-setup/
├── install.sh        # Main installation script
├── uninstall.sh      # Removal script
├── configure.sh      # Post-install configuration tool
├── README.md         # This file
├── assets/
│   └── logo.png      # Microchip logo
├── config/           # Configuration templates
└── scripts/          # Additional helper scripts
```

---

## License

Copyright (c) Microchip Technology Inc. All rights reserved.

pyX2Cscope is proprietary software. See [pyX2Cscope documentation](https://x2cscope.github.io/pyx2cscope/) for license details.

---

## Contact

- **pyX2Cscope Documentation**: https://x2cscope.github.io/pyx2cscope/
- **Microchip Support**: https://www.microchip.com/support
- **GitHub Issues**: Report bugs and feature requests

---

*Generated for Microchip Technology Inc. motor control applications.*
